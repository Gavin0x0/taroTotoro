export default {
  navigationBarTitleText: '主页「Home」'
}
