export default {
  navigationBarTitleText: '教师主页'
}
