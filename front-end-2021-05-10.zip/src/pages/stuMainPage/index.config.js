export default {
  navigationBarTitleText: '学生主页'
}
