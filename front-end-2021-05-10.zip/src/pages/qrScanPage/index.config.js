export default {
  navigationBarTitleText: '扫码'
}
