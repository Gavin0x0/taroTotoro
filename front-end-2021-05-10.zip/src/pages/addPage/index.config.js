export default {
  navigationBarTitleText: '进入教室「Add」'
}
