export default {
  navigationBarTitleText: '接口测试页'
}
